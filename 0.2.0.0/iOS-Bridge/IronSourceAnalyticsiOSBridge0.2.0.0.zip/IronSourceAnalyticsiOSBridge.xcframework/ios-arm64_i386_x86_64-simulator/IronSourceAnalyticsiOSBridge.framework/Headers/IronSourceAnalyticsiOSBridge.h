//
//  Analytics_iOSBridge.h
//  Analytics-iOSBridge
//
//  Created by Bar David on 15/06/2021.
//

#import <Foundation/Foundation.h>

@interface IronSourceAnalyticsiOSBridge : NSObject

@end
